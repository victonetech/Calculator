'use strict'

console.log("I'm module! (❁´◡`❁)")

// or 
// export function module_function(msg) { return `msg: ${msg}` } 